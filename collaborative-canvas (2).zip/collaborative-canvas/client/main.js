// Handle color picker
document.getElementById("colorPicker").addEventListener("input", (e) => {
  brushColor = e.target.value;
});

// Handle stroke width
document.getElementById("strokeWidth").addEventListener("input", (e) => {
  brushSize = e.target.value;
});

// Handle undo button
document.getElementById("undoBtn").addEventListener("click", () => {
  socket.emit("undo");
});
