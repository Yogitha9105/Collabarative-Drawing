const canvas = document.getElementById("drawingCanvas");
const ctx = canvas.getContext("2d");

canvas.width = window.innerWidth;
canvas.height = window.innerHeight - 80; // toolbar height

let drawing = false;
let brushColor = "#000000";
let brushSize = 5;
let tool = "brush";
let paths = [];
let undonePaths = [];

// Resize canvas dynamically
window.addEventListener("resize", () => {
  const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
  canvas.width = window.innerWidth;
  canvas.height = window.innerHeight - 80;
  ctx.putImageData(imageData, 0, 0);
});

// Start drawing
canvas.addEventListener("mousedown", (e) => {
  drawing = true;
  ctx.beginPath();
  ctx.moveTo(e.clientX, e.clientY - 80);
  undonePaths = [];
  paths.push([{ x: e.clientX, y: e.clientY - 80, color: brushColor, size: brushSize, tool }]);
});

// Draw while moving
canvas.addEventListener("mousemove", (e) => {
  if (!drawing) return;
  const y = e.clientY - 80;

  const currentPath = paths[paths.length - 1];
  currentPath.push({ x: e.clientX, y, color: brushColor, size: brushSize, tool });

  if (tool === "eraser") {
    ctx.strokeStyle = "#ffffff";
  } else {
    ctx.strokeStyle = brushColor;
  }
  ctx.lineWidth = brushSize;
  ctx.lineCap = "round";

  ctx.lineTo(e.clientX, y);
  ctx.stroke();
});

// Stop drawing
canvas.addEventListener("mouseup", () => (drawing = false));
canvas.addEventListener("mouseleave", () => (drawing = false));

// Redraw function
function redraw() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  for (const path of paths) {
    ctx.beginPath();
    for (let i = 1; i < path.length; i++) {
      const prev = path[i - 1];
      const curr = path[i];
      ctx.strokeStyle = curr.tool === "eraser" ? "#ffffff" : curr.color;
      ctx.lineWidth = curr.size;
      ctx.lineCap = "round";
      ctx.moveTo(prev.x, prev.y);
      ctx.lineTo(curr.x, curr.y);
      ctx.stroke();
    }
  }
}

// Undo and Redo
document.getElementById("undoBtn").addEventListener("click", () => {
  if (paths.length > 0) {
    undonePaths.push(paths.pop());
    redraw();
  }
});

document.getElementById("redoBtn").addEventListener("click", () => {
  if (undonePaths.length > 0) {
    paths.push(undonePaths.pop());
    redraw();
  }
});

// Clear canvas
document.getElementById("clearBtn").addEventListener("click", () => {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  paths = [];
  undonePaths = [];
});

// Save image
document.getElementById("saveBtn").addEventListener("click", () => {
  const link = document.createElement("a");
  link.download = "drawing.png";
  link.href = canvas.toDataURL();
  link.click();
});

// Tool change
document.getElementById("brushBtn").addEventListener("click", () => {
  tool = "brush";
  setActiveTool("brushBtn");
});

document.getElementById("eraserBtn").addEventListener("click", () => {
  tool = "eraser";
  setActiveTool("eraserBtn");
});

function setActiveTool(id) {
  document.querySelectorAll(".tool-btn").forEach(btn => btn.classList.remove("active"));
  document.getElementById(id).classList.add("active");
}

// Color picker and size control
document.getElementById("colorPicker").addEventListener("change", (e) => {
  brushColor = e.target.value;
});

document.getElementById("brushSize").addEventListener("input", (e) => {
  brushSize = e.target.value;
});
