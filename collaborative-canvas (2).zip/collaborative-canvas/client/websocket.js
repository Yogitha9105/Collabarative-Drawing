const socket = io();

// Receive drawing from others
socket.on("draw", (data) => {
  drawPath(data.path, data.color, data.size);
});

// When a new user joins, redraw everything
socket.on("init-canvas", (actions) => {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  actions.forEach(a => drawPath(a.path, a.color, a.size));
});

// Update user list
socket.on("user-list", (users) => {
  const userDiv = document.getElementById("userList");
  userDiv.innerHTML =
    "👥 Users Online:<br>" +
    Object.values(users)
      .map(u => `<span style='color:${u.color}'>●</span>`)
      .join(" ");
});

// Send draw data to server
function sendDrawData(path, color, size) {
  socket.emit("draw", { path, color, size });
}
