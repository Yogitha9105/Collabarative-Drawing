const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const path = require("path");

const app = express();
const server = http.createServer(app);
const io = new Server(server);

// Serve static client files
app.use(express.static('client'));


let users = {};   // Track users and their colors
let actions = []; // Store drawing actions (for undo/redo, new users)

// When a user connects
io.on("connection", (socket) => {
  console.log("New user connected:", socket.id);

  const userColor = `hsl(${Math.random() * 360}, 100%, 50%)`;
  users[socket.id] = { color: userColor };

  // Notify all users
  io.emit("user-list", users);

  // Send existing canvas state
  socket.emit("init-canvas", actions);

  // Handle drawing data from this user
  socket.on("draw", (data) => {
    actions.push(data);
    socket.broadcast.emit("draw", data);
  });

  // Handle global undo
  socket.on("undo", () => {
    actions.pop();
    io.emit("init-canvas", actions);
  });

  // On disconnect
  socket.on("disconnect", () => {
    delete users[socket.id];
    io.emit("user-list", users);
    console.log("User disconnected:", socket.id);
  });
});

// Start the server
const PORT = 4000;
server.listen(PORT, () =>
  console.log(`✅ Server running at http://localhost:${PORT}`)
);
