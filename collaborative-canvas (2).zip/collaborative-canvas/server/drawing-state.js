// This can store and manage the drawing actions for persistence or undo/redo logic.
let actions = [];

module.exports = {
  getActions() {
    return actions;
  },
  addAction(action) {
    actions.push(action);
  },
  undoLast() {
    actions.pop();
  },
  clear() {
    actions = [];
  },
};
