// Future enhancement: Manage multiple drawing rooms
module.exports = {
  rooms: {},
  createRoom(roomId) {
    this.rooms[roomId] = [];
  },
  getRoomActions(roomId) {
    return this.rooms[roomId] || [];
  },
  addAction(roomId, action) {
    if (!this.rooms[roomId]) this.rooms[roomId] = [];
    this.rooms[roomId].push(action);
  },
};
