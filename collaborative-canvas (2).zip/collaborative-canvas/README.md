# 🖌 Real-Time Collaborative Drawing Canvas

A multi-user real-time drawing board built with **HTML5 Canvas**, **Vanilla JavaScript**, and **Node.js (Socket.io)**.

## 🚀 Features
- Real-time synchronized drawing across users
- Custom brush color and width
- Live user indicators
- Global undo support
- Clean vanilla JS + Canvas implementation

## 🧰 Setup
```bash
npm install
npm start
